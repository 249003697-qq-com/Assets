

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu('custom/PlayAnim')
export default class PlayAnim extends cc.Component {
    @property(cc.Animation)
    animation: cc.Animation = null

    particles: cc.ParticleSystem[] = null

    _isFindParticleSystem = false


    onEnable() {
        let clip = this.animation.getClips()
        this.animation.play(clip[0].name);
        if (!this._isFindParticleSystem) {
            this.particles = this.animation.node.getComponentsInChildren(cc.ParticleSystem)
            this._isFindParticleSystem = true
        }
        let length = this.particles.length
        for (let i = 0; i < length; i++) {
            let particle = this.particles[i]
            if (particle) {
                particle.stopSystem()
                particle.resetSystem()
            }
        }
    }

    onDisable() {
        this.animation.stop()
    }


}
