

const { ccclass, property } = cc._decorator;

@ccclass
export default class PlayParticle extends cc.Component {

    @property(cc.ParticleSystem)
    particle: cc.ParticleSystem = null

    @property(Number)
    duration: number = 0

    onEnable() {
        let self = this
        if (!self.particle) {
            return
        }
        self.unscheduleAllCallbacks()
        self.particle.node.active = true
        self.particle.resetSystem()

        let duration = 0
        if (self.duration > 0) {
            duration = self.duration
        } else if (self.particle.duration > 0) {
            duration = self.particle.duration
        }

        if (duration > 0) {
            self.scheduleOnce(() => {
                if (!self || !self.isValid) {
                    return
                }
                self.particle.node.active = false
            }, duration)
        }

    }

    onDisable() {
        this.unscheduleAllCallbacks()
    }

    onDestroy() {
        this.unscheduleAllCallbacks()
    }

}
